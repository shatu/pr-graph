package data;

import java.util.ArrayList;

public class OcrLetterSequence {

	public int sequenceID, startLetterID, endLetterID;
	public String word;
	public int length;
	
	public OcrLetterSequence(int sequenceID, int startLetterID, int endLetterID, 
			ArrayList<OcrLetterNode> nodes) {
		this.sequenceID = sequenceID;
		this.startLetterID = startLetterID;
		this.endLetterID = endLetterID;
		word = "";
		for (int i = startLetterID; i < endLetterID; i++) {
			word += nodes.get(i).letter;
		}
		this.length = endLetterID - startLetterID;
	}
}
